#ifndef PC_GUI_H
#define PC_GUI_H

#ifdef PC_GUI

#include "SDL.h"

enum
{
  PC_KEY_UP = 0,
  PC_KEY_DOWN,
  PC_KEY_LEFT,
  PC_KEY_RIGHT,
  PC_KEY_A,
  PC_KEY_B,
  PC_KEY_L,
  PC_KEY_R,
  PC_KEY_START,
  PC_KEY_SELECT,
  PC_KEY_COUNT
};

extern SDLKey pc_gui_keys[PC_KEY_COUNT];
extern int pc_gui_rom_ready;

void pc_gui_init(void);
void pc_gui_attach_menu(void);
void pc_gui_poll(void);
void pc_gui_idle(void);
int pc_gui_on_key(SDLKey key);
void pc_gui_load_rom_path(const char *path);

#endif

#endif
