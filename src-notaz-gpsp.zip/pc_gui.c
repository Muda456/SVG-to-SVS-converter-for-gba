#ifdef PC_GUI

#include "common.h"
#include "pc_gui.h"
#include <windows.h>
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <wchar.h>
#include "SDL_syswm.h"

#define CLASSIC_MEM_BASE 1731
#define SVG_MEM_BASE 2243
#define IWRAM_SIZE 0x8000
#define EWRAM_SIZE 0x40000
#define VRAM_SIZE 0x18000
#define OAM_SIZE 0x400
#define PAL_SIZE 0x400
#define IO_SIZE 0x8000
#define MAIN_OFF 768
#define CLASSIC_REG 256
#define CLONE_SPSR_OFF 544
#define SCREEN_BYTES (240 * 160 * 2)
#define CLASSIC_GPSP_SIZE 506943

#define IDM_OPEN_ROM    4001
#define IDM_SAVE_STATE  4002
#define IDM_LOAD_STATE  4003
#define IDM_IMPORT_SVG  4004
#define IDM_EXIT        4005
#define IDM_SCALE_1     4011
#define IDM_SCALE_2     4012
#define IDM_SCALE_3     4013
#define IDM_SCALE_4     4014
#define IDM_KEYS        4020
#define IDM_KEY_SET0    4100

int pc_gui_rom_ready = 0;
SDLKey pc_gui_keys[PC_KEY_COUNT] =
{
  SDLK_UP, SDLK_DOWN, SDLK_LEFT, SDLK_RIGHT,
  SDLK_LALT, SDLK_LCTRL, SDLK_LSHIFT, SDLK_x,
  SDLK_RETURN, SDLK_RSHIFT
};

static const SDLKey pc_gui_keys_default[PC_KEY_COUNT] =
{
  SDLK_UP, SDLK_DOWN, SDLK_LEFT, SDLK_RIGHT,
  SDLK_LALT, SDLK_LCTRL, SDLK_LSHIFT, SDLK_x,
  SDLK_RETURN, SDLK_RSHIFT
};

static const wchar_t *pc_key_labels[PC_KEY_COUNT] =
{
  L"上", L"下", L"左", L"右", L"A", L"B", L"L", L"R", L"Start", L"Select"
};

static HWND g_hwnd = NULL;
static WNDPROC g_old_proc = NULL;
static HMENU g_menu = NULL;
static int g_pending = 0;
static wchar_t g_pending_path[MAX_PATH];
static int g_capture = -1;
static HWND g_key_dlg = NULL;
static HWND g_key_val[PC_KEY_COUNT];
static HWND g_key_status = NULL;

static HWND sdl_hwnd(void)
{
  SDL_SysWMinfo info;
  SDL_VERSION(&info.version);
  if(!SDL_GetWMInfo(&info))
    return NULL;
  return info.window;
}

static int to_acp(const wchar_t *w, char *out, int n)
{
  return WideCharToMultiByte(CP_ACP, 0, w, -1, out, n, NULL, NULL) > 0;
}

static int to_wide(const char *a, wchar_t *out, int n)
{
  return MultiByteToWideChar(CP_ACP, 0, a, -1, out, n) > 0;
}

static void rom_state_path(char *out, size_t n, const char *suffix)
{
  char *dot;
  char *slash;

  if(!gamepak_filename[0])
  {
    snprintf(out, n, "%s\\rom%s", main_path, suffix);
    return;
  }
  strncpy(out, gamepak_filename, n - 1);
  out[n - 1] = 0;
  slash = strrchr(out, '\\');
  if(!slash)
    slash = strrchr(out, '/');
  dot = strrchr(out, '.');
  if(dot && (!slash || dot > slash))
    *dot = 0;
  strncat(out, suffix, n - strlen(out) - 1);
}

static void update_title(void)
{
  wchar_t title[MAX_PATH + 32];
  wchar_t name[MAX_PATH];
  char *slash;

  if(!gamepak_filename[0])
  {
    SetWindowTextW(g_hwnd, L"gpSP");
    SDL_WM_SetCaption("gpSP", NULL);
    return;
  }
  slash = strrchr(gamepak_filename, '\\');
  if(!slash)
    slash = strrchr(gamepak_filename, '/');
  slash = slash ? slash + 1 : gamepak_filename;
  to_wide(slash, name, MAX_PATH);
  _snwprintf(title, MAX_PATH + 32, L"gpSP  -  %s", name);
  title[MAX_PATH + 31] = 0;
  if(g_hwnd)
    SetWindowTextW(g_hwnd, title);
}

static void load_cfg(void)
{
  char path[512];
  FILE *fp;
  char line[128];
  int i, v;

  snprintf(path, sizeof(path), "%s\\gpsp_gui.cfg", main_path);
  fp = fopen(path, "r");
  if(!fp)
    return;
  while(fgets(line, sizeof(line), fp))
  {
    if(sscanf(line, "scale=%d", &v) == 1)
    {
      if(v >= 1 && v <= 4)
        video_scale = (u32)v;
    }
    else if(sscanf(line, "key_%d=%d", &i, &v) == 2)
    {
      if(i >= 0 && i < PC_KEY_COUNT && v > 0)
        pc_gui_keys[i] = (SDLKey)v;
    }
  }
  fclose(fp);
}

static void save_cfg(void)
{
  char path[512];
  FILE *fp;
  int i;

  snprintf(path, sizeof(path), "%s\\gpsp_gui.cfg", main_path);
  fp = fopen(path, "w");
  if(!fp)
    return;
  fprintf(fp, "scale=%u\n", video_scale);
  for(i = 0; i < PC_KEY_COUNT; i++)
    fprintf(fp, "key_%d=%d\n", i, (int)pc_gui_keys[i]);
  fclose(fp);
}

static void fit_client(HWND hwnd)
{
  RECT wr, cr;
  int extra_w, extra_h;
  int cw = 240 * (int)video_scale;
  int ch = 160 * (int)video_scale;

  if(!hwnd)
    return;
  GetWindowRect(hwnd, &wr);
  GetClientRect(hwnd, &cr);
  extra_w = (wr.right - wr.left) - cr.right;
  extra_h = (wr.bottom - wr.top) - cr.bottom;
  SetWindowPos(hwnd, NULL, 0, 0, cw + extra_w, ch + extra_h,
   SWP_NOMOVE | SWP_NOZORDER);
}

static void sync_scale_checks(void)
{
  UINT id = IDM_SCALE_1 + (video_scale ? video_scale - 1 : 0);
  if(!g_menu)
    return;
  CheckMenuRadioItem(g_menu, IDM_SCALE_1, IDM_SCALE_4, id, MF_BYCOMMAND);
}

static HMENU build_menu(void)
{
  HMENU bar = CreateMenu();
  HMENU file = CreatePopupMenu();
  HMENU opt = CreatePopupMenu();
  HMENU video = CreatePopupMenu();

  AppendMenuW(file, MF_STRING, IDM_OPEN_ROM, L"选择 ROM...");
  AppendMenuW(file, MF_SEPARATOR, 0, NULL);
  AppendMenuW(file, MF_STRING, IDM_SAVE_STATE, L"保存即时存档...");
  AppendMenuW(file, MF_STRING, IDM_LOAD_STATE, L"读取即时存档...");
  AppendMenuW(file, MF_STRING, IDM_IMPORT_SVG, L"导入 SVG 存档...");
  AppendMenuW(file, MF_SEPARATOR, 0, NULL);
  AppendMenuW(file, MF_STRING, IDM_EXIT, L"退出");

  AppendMenuW(video, MF_STRING, IDM_SCALE_1, L"×1   (240 × 160)");
  AppendMenuW(video, MF_STRING, IDM_SCALE_2, L"×2   (480 × 320)");
  AppendMenuW(video, MF_STRING, IDM_SCALE_3, L"×3   (720 × 480)");
  AppendMenuW(video, MF_STRING, IDM_SCALE_4, L"×4   (960 × 640)");

  AppendMenuW(opt, MF_POPUP, (UINT_PTR)video, L"视频画面");
  AppendMenuW(opt, MF_STRING, IDM_KEYS, L"按键设置...");

  AppendMenuW(bar, MF_POPUP, (UINT_PTR)file, L"文件(&F)");
  AppendMenuW(bar, MF_POPUP, (UINT_PTR)opt, L"选项(&O)");
  return bar;
}

static LRESULT CALLBACK gui_wndproc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  if(msg == WM_COMMAND)
  {
    g_pending = (int)LOWORD(wParam);
    return 0;
  }
  if(msg == WM_DROPFILES)
  {
    HDROP drop = (HDROP)wParam;
    if(DragQueryFileW(drop, 0, g_pending_path, MAX_PATH))
    {
      wchar_t *dot = wcsrchr(g_pending_path, L'.');
      if(dot && _wcsicmp(dot, L".svg") == 0)
        g_pending = IDM_IMPORT_SVG | 0x10000;
      else
        g_pending = IDM_OPEN_ROM | 0x10000;
    }
    DragFinish(drop);
    return 0;
  }
  if(g_old_proc)
    return CallWindowProcA(g_old_proc, hwnd, msg, wParam, lParam);
  return DefWindowProcA(hwnd, msg, wParam, lParam);
}

void pc_gui_attach_menu(void)
{
  HWND hwnd = sdl_hwnd();
  if(!hwnd)
    return;

  if(hwnd != g_hwnd)
  {
    g_hwnd = hwnd;
    g_old_proc = (WNDPROC)SetWindowLongPtrA(hwnd, GWLP_WNDPROC, (LONG_PTR)gui_wndproc);
    DragAcceptFiles(hwnd, TRUE);
  }

  g_menu = build_menu();
  SetMenu(hwnd, g_menu);
  DrawMenuBar(hwnd);
  sync_scale_checks();
  fit_client(hwnd);
  SDL_ShowCursor(1);
  update_title();
}

static int browse_open(const wchar_t *filter, const wchar_t *title, wchar_t *buf)
{
  OPENFILENAMEW ofn;
  memset(&ofn, 0, sizeof ofn);
  ofn.lStructSize = sizeof ofn;
  ofn.hwndOwner = g_hwnd;
  ofn.lpstrFilter = filter;
  ofn.lpstrFile = buf;
  ofn.nMaxFile = MAX_PATH;
  ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER | OFN_NOCHANGEDIR;
  ofn.lpstrTitle = title;
  buf[0] = 0;
  return GetOpenFileNameW(&ofn);
}

static int browse_save(const wchar_t *filter, const wchar_t *title,
 const wchar_t *suggest, wchar_t *buf)
{
  OPENFILENAMEW ofn;
  memset(&ofn, 0, sizeof ofn);
  ofn.lStructSize = sizeof ofn;
  ofn.hwndOwner = g_hwnd;
  ofn.lpstrFilter = filter;
  ofn.lpstrFile = buf;
  ofn.nMaxFile = MAX_PATH;
  ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_EXPLORER | OFN_NOCHANGEDIR;
  ofn.lpstrDefExt = L"svs";
  ofn.lpstrTitle = title;
  if(suggest && suggest[0])
  {
    wcsncpy(buf, suggest, MAX_PATH - 1);
    buf[MAX_PATH - 1] = 0;
  }
  else
    buf[0] = 0;
  return GetSaveFileNameW(&ofn);
}

static int apply_rom_w(const wchar_t *wpath)
{
  char path[MAX_PATH];
  if(!to_acp(wpath, path, MAX_PATH))
  {
    MessageBoxW(g_hwnd, L"路径无法转换成当前系统编码。", L"gpSP", MB_OK | MB_ICONERROR);
    return 0;
  }
  if(load_gamepak(path) == -1)
  {
    MessageBoxW(g_hwnd, L"无法加载这个 ROM。", L"gpSP", MB_OK | MB_ICONERROR);
    return 0;
  }
  reset_gba();
  reg[CHANGED_PC_STATUS] = 1;
  pc_gui_rom_ready = 1;
  update_title();
  return 1;
}

void pc_gui_load_rom_path(const char *path)
{
  wchar_t w[MAX_PATH];
  if(to_wide(path, w, MAX_PATH))
    apply_rom_w(w);
}

static void do_open_rom(const wchar_t *preset)
{
  wchar_t buf[MAX_PATH];
  if(preset && preset[0])
  {
    apply_rom_w(preset);
    return;
  }
  if(browse_open(L"GBA ROM (*.gba;*.bin;*.zip)\0*.gba;*.bin;*.zip\0所有文件 (*.*)\0*.*\0",
   L"选择 ROM", buf))
    apply_rom_w(buf);
}

static int need_rom(void)
{
  if(pc_gui_rom_ready && gamepak_filename[0])
    return 1;
  MessageBoxW(g_hwnd, L"请先通过「文件 → 选择 ROM」加载游戏。", L"gpSP",
   MB_OK | MB_ICONINFORMATION);
  return 0;
}

static void do_save_state(void)
{
  char def_a[MAX_PATH];
  wchar_t def_w[MAX_PATH], buf[MAX_PATH];
  char path[MAX_PATH];
  u16 *shot;

  if(!need_rom())
    return;
  rom_state_path(def_a, sizeof(def_a), "0.svs");
  to_wide(def_a, def_w, MAX_PATH);
  if(!browse_save(L"gpSP 即时存档 (*.svs)\0*.svs\0所有文件 (*.*)\0*.*\0",
   L"保存即时存档", def_w, buf))
    return;
  if(!to_acp(buf, path, MAX_PATH))
    return;
  shot = copy_screen();
  save_state(path, shot);
  free(shot);
}

static void do_load_state_file(const char *path)
{
  load_state((char *)path);
  reg[CHANGED_PC_STATUS] = 1;
}

static void do_load_state(void)
{
  wchar_t buf[MAX_PATH];
  char path[MAX_PATH];

  if(!need_rom())
    return;
  if(!browse_open(L"gpSP 即时存档 (*.svs)\0*.svs\0所有文件 (*.*)\0*.*\0",
   L"读取即时存档", buf))
    return;
  if(!to_acp(buf, path, MAX_PATH))
    return;
  do_load_state_file(path);
}

static int svg_unique_bytes(const unsigned char *p, int n)
{
  char seen[256];
  int i, c = 0;
  memset(seen, 0, sizeof seen);
  for(i = 0; i < n; i++)
    if(!seen[p[i]]) { seen[p[i]] = 1; c++; }
  return c;
}

static const wchar_t *convert_svg_w(const wchar_t *svg_path, const wchar_t *svs_path)
{
  HANDLE hf;
  DWORD nread = 0, nwrite = 0, sz = 0;
  unsigned char *data = NULL, *out = NULL, *body;
  int io, after, body_len, need;

  hf = CreateFileW(svg_path, GENERIC_READ, FILE_SHARE_READ, NULL,
   OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hf == INVALID_HANDLE_VALUE)
    return L"无法打开 SVG 文件。";
  sz = GetFileSize(hf, NULL);
  if(sz < (DWORD)(SVG_MEM_BASE + IWRAM_SIZE + EWRAM_SIZE + VRAM_SIZE + 16))
  {
    CloseHandle(hf);
    return L"文件太小，不像山寨机 .svg 即时存档。";
  }
  data = (unsigned char *)malloc(sz);
  if(!data) { CloseHandle(hf); return L"内存不足。"; }
  if(!ReadFile(hf, data, sz, &nread, NULL) || nread != sz)
  {
    free(data); CloseHandle(hf);
    return L"读取 SVG 失败。";
  }
  CloseHandle(hf);

  io = SVG_MEM_BASE + IWRAM_SIZE + EWRAM_SIZE + VRAM_SIZE + OAM_SIZE + PAL_SIZE;
  after = io + IO_SIZE;
  if((int)sz < after)
  {
    free(data);
    return L"文件长度不够，缺少内存数据。";
  }

  body_len = CLASSIC_REG + (MAIN_OFF - CLONE_SPSR_OFF) +
   (CLASSIC_MEM_BASE - MAIN_OFF) + (after - SVG_MEM_BASE);
  need = SCREEN_BYTES + 4 + body_len;
  out = (unsigned char *)calloc(1, CLASSIC_GPSP_SIZE > need ? CLASSIC_GPSP_SIZE : need);
  if(!out) { free(data); return L"内存不足。"; }

  if((int)sz >= after + SCREEN_BYTES && svg_unique_bytes(data + after, SCREEN_BYTES) > 40)
    memcpy(out, data + after, SCREEN_BYTES);

  body = out + SCREEN_BYTES + 4;
  memcpy(body, data, CLASSIC_REG);
  memcpy(body + CLASSIC_REG, data + CLONE_SPSR_OFF, MAIN_OFF - CLONE_SPSR_OFF);
  memcpy(body + CLASSIC_REG + (MAIN_OFF - CLONE_SPSR_OFF), data + MAIN_OFF,
   CLASSIC_MEM_BASE - MAIN_OFF);
  memcpy(body + CLASSIC_REG + (MAIN_OFF - CLONE_SPSR_OFF) + (CLASSIC_MEM_BASE - MAIN_OFF),
   data + SVG_MEM_BASE, after - SVG_MEM_BASE);

  hf = CreateFileW(svs_path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
   FILE_ATTRIBUTE_NORMAL, NULL);
  if(hf == INVALID_HANDLE_VALUE)
  {
    free(data); free(out);
    return L"无法写入转换后的 .svs（游戏目录是否只读）。";
  }
  if(!WriteFile(hf, out, CLASSIC_GPSP_SIZE, &nwrite, NULL) || nwrite != CLASSIC_GPSP_SIZE)
  {
    CloseHandle(hf); free(data); free(out);
    return L"写入 .svs 失败。";
  }
  CloseHandle(hf);
  free(data);
  free(out);
  return NULL;
}

static void do_import_svg(const wchar_t *preset)
{
  wchar_t svg[MAX_PATH], svs_w[MAX_PATH];
  char svs_a[MAX_PATH];
  const wchar_t *err;

  if(!need_rom())
    return;
  if(preset && preset[0])
    wcsncpy(svg, preset, MAX_PATH - 1);
  else if(!browse_open(L"山寨机即时存档 (*.svg)\0*.svg\0所有文件 (*.*)\0*.*\0",
   L"导入 SVG 存档", svg))
    return;
  svg[MAX_PATH - 1] = 0;

  rom_state_path(svs_a, sizeof(svs_a), "0.svs");
  to_wide(svs_a, svs_w, MAX_PATH);
  if(GetFileAttributesW(svs_w) != INVALID_FILE_ATTRIBUTES)
  {
    if(MessageBoxW(g_hwnd, L"游戏目录里已有同名 .svs，要覆盖并读取吗？",
     L"导入 SVG", MB_YESNO | MB_ICONQUESTION) != IDYES)
      return;
  }

  err = convert_svg_w(svg, svs_w);
  if(err)
  {
    MessageBoxW(g_hwnd, err, L"导入失败", MB_OK | MB_ICONERROR);
    return;
  }
  do_load_state_file(svs_a);
}

static void refresh_key_labels(void)
{
  int i;
  wchar_t buf[64];
  char name[32];

  for(i = 0; i < PC_KEY_COUNT; i++)
  {
    if(!g_key_val[i])
      continue;
    strncpy(name, SDL_GetKeyName(pc_gui_keys[i]), sizeof(name) - 1);
    name[sizeof(name) - 1] = 0;
    to_wide(name, buf, 64);
    SetWindowTextW(g_key_val[i], buf);
  }
}

static SDLKey vk_to_sdl(WPARAM vk)
{
  if(vk == VK_SHIFT)
    return (GetKeyState(VK_RSHIFT) & 0x8000) ? SDLK_RSHIFT : SDLK_LSHIFT;
  if(vk == VK_CONTROL)
    return (GetKeyState(VK_RCONTROL) & 0x8000) ? SDLK_RCTRL : SDLK_LCTRL;
  if(vk == VK_MENU)
    return (GetKeyState(VK_RMENU) & 0x8000) ? SDLK_RALT : SDLK_LALT;
  if(vk == VK_UP) return SDLK_UP;
  if(vk == VK_DOWN) return SDLK_DOWN;
  if(vk == VK_LEFT) return SDLK_LEFT;
  if(vk == VK_RIGHT) return SDLK_RIGHT;
  if(vk == VK_RETURN) return SDLK_RETURN;
  if(vk == VK_SPACE) return SDLK_SPACE;
  if(vk == VK_TAB) return SDLK_TAB;
  if(vk == VK_BACK) return SDLK_BACKSPACE;
  if(vk == VK_ESCAPE) return SDLK_ESCAPE;
  if(vk == VK_LSHIFT) return SDLK_LSHIFT;
  if(vk == VK_RSHIFT) return SDLK_RSHIFT;
  if(vk == VK_LCONTROL) return SDLK_LCTRL;
  if(vk == VK_RCONTROL) return SDLK_RCTRL;
  if(vk == VK_LMENU) return SDLK_LALT;
  if(vk == VK_RMENU) return SDLK_RALT;
  if(vk >= 'A' && vk <= 'Z') return (SDLKey)(SDLK_a + (vk - 'A'));
  if(vk >= '0' && vk <= '9') return (SDLKey)(SDLK_0 + (vk - '0'));
  if(vk >= VK_F1 && vk <= VK_F12) return (SDLKey)(SDLK_F1 + (vk - VK_F1));
  if(vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9)
    return (SDLKey)(SDLK_KP0 + (vk - VK_NUMPAD0));
  if(vk == VK_ADD) return SDLK_KP_PLUS;
  if(vk == VK_SUBTRACT) return SDLK_KP_MINUS;
  if(vk == VK_OEM_PLUS) return SDLK_EQUALS;
  if(vk == VK_OEM_MINUS) return SDLK_MINUS;
  return SDLK_UNKNOWN;
}

static void assign_key(int idx, SDLKey key)
{
  int i;
  if(idx < 0 || idx >= PC_KEY_COUNT || key == SDLK_UNKNOWN || key == SDLK_ESCAPE)
    return;
  for(i = 0; i < PC_KEY_COUNT; i++)
  {
    if(i != idx && pc_gui_keys[i] == key)
      pc_gui_keys[i] = SDLK_UNKNOWN;
  }
  pc_gui_keys[idx] = key;
  g_capture = -1;
  save_cfg();
  refresh_key_labels();
  if(g_key_status)
    SetWindowTextW(g_key_status, L"已更新。点「设置」可继续改键。");
}

static LRESULT CALLBACK key_dlg_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_COMMAND:
    {
      int id = (int)LOWORD(wParam);
      if(id >= IDM_KEY_SET0 && id < IDM_KEY_SET0 + PC_KEY_COUNT)
      {
        g_capture = id - IDM_KEY_SET0;
        if(g_key_status)
          SetWindowTextW(g_key_status, L"请按下要映射的键盘按键…");
        SetFocus(hwnd);
        return 0;
      }
      if(id == IDOK || id == IDCANCEL)
      {
        DestroyWindow(hwnd);
        return 0;
      }
      if(id == 4201)
      {
        memcpy(pc_gui_keys, pc_gui_keys_default, sizeof(pc_gui_keys));
        save_cfg();
        refresh_key_labels();
        if(g_key_status)
          SetWindowTextW(g_key_status, L"已恢复默认按键。");
        return 0;
      }
      break;
    }
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
      if(g_capture >= 0)
      {
        assign_key(g_capture, vk_to_sdl(wParam));
        return 0;
      }
      break;
    case WM_CLOSE:
      DestroyWindow(hwnd);
      return 0;
    case WM_DESTROY:
      g_key_dlg = NULL;
      g_capture = -1;
      memset(g_key_val, 0, sizeof(g_key_val));
      g_key_status = NULL;
      return 0;
  }
  return DefWindowProcW(hwnd, msg, wParam, lParam);
}

static void show_key_dialog(void)
{
  HFONT font;
  HWND hwnd, btn;
  int i, y;
  WNDCLASSW wc;

  if(g_key_dlg)
  {
    SetForegroundWindow(g_key_dlg);
    return;
  }

  memset(&wc, 0, sizeof wc);
  wc.lpfnWndProc = key_dlg_proc;
  wc.hInstance = GetModuleHandle(NULL);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
  wc.lpszClassName = L"gpSPKeyDlg";
  RegisterClassW(&wc);

  hwnd = CreateWindowExW(WS_EX_DLGMODALFRAME, L"gpSPKeyDlg", L"按键设置",
   WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
   CW_USEDEFAULT, CW_USEDEFAULT, 360, 430, g_hwnd, NULL, wc.hInstance, NULL);
  font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
  g_key_dlg = hwnd;

  CreateWindowW(L"STATIC", L"点「设置」后按下键盘按键，即可改映射。",
   WS_CHILD | WS_VISIBLE, 16, 10, 320, 20, hwnd, NULL, NULL, NULL);

  for(i = 0; i < PC_KEY_COUNT; i++)
  {
    y = 36 + i * 30;
    CreateWindowW(L"STATIC", pc_key_labels[i],
     WS_CHILD | WS_VISIBLE, 20, y + 4, 70, 20, hwnd, NULL, NULL, NULL);
    g_key_val[i] = CreateWindowExW(WS_EX_CLIENTEDGE, L"STATIC", L"",
     WS_CHILD | WS_VISIBLE, 100, y, 140, 24, hwnd, NULL, NULL, NULL);
    btn = CreateWindowW(L"BUTTON", L"设置",
     WS_CHILD | WS_VISIBLE, 250, y, 70, 24, hwnd, (HMENU)(INT_PTR)(IDM_KEY_SET0 + i),
     NULL, NULL);
    SendMessageW(g_key_val[i], WM_SETFONT, (WPARAM)font, 1);
    SendMessageW(btn, WM_SETFONT, (WPARAM)font, 1);
  }

  g_key_status = CreateWindowW(L"STATIC", L"",
   WS_CHILD | WS_VISIBLE, 16, 340, 320, 20, hwnd, NULL, NULL, NULL);
  btn = CreateWindowW(L"BUTTON", L"恢复默认",
   WS_CHILD | WS_VISIBLE, 80, 366, 90, 26, hwnd, (HMENU)4201, NULL, NULL);
  SendMessageW(btn, WM_SETFONT, (WPARAM)font, 1);
  btn = CreateWindowW(L"BUTTON", L"关闭",
   WS_CHILD | WS_VISIBLE, 180, 366, 90, 26, hwnd, (HMENU)IDCANCEL, NULL, NULL);
  SendMessageW(btn, WM_SETFONT, (WPARAM)font, 1);

  refresh_key_labels();
  ShowWindow(hwnd, SW_SHOW);
}

int pc_gui_on_key(SDLKey key)
{
  if(g_capture >= 0)
  {
    assign_key(g_capture, key);
    return 1;
  }
  if(g_key_dlg)
    return 1;
  return 0;
}

static void apply_pending(void)
{
  int cmd = g_pending;
  int dropped = 0;

  g_pending = 0;
  if(!cmd)
    return;
  if(cmd & 0x10000)
  {
    dropped = 1;
    cmd &= 0xFFFF;
  }

  switch(cmd)
  {
    case IDM_OPEN_ROM:
      do_open_rom(dropped ? g_pending_path : NULL);
      break;
    case IDM_SAVE_STATE:
      do_save_state();
      break;
    case IDM_LOAD_STATE:
      do_load_state();
      break;
    case IDM_IMPORT_SVG:
      do_import_svg(dropped ? g_pending_path : NULL);
      break;
    case IDM_EXIT:
      save_cfg();
      quit();
      break;
    case IDM_SCALE_1:
    case IDM_SCALE_2:
    case IDM_SCALE_3:
    case IDM_SCALE_4:
      set_pc_video_scale((u32)(cmd - IDM_SCALE_1 + 1));
      save_cfg();
      break;
    case IDM_KEYS:
      show_key_dialog();
      break;
  }
  g_pending_path[0] = 0;
}

void pc_gui_poll(void)
{
  HWND hwnd = sdl_hwnd();
  if(hwnd && hwnd != g_hwnd)
    pc_gui_attach_menu();
  apply_pending();
}

void pc_gui_idle(void)
{
  SDL_Event event;

  pc_gui_poll();
  while(SDL_PollEvent(&event))
  {
    if(event.type == SDL_QUIT)
    {
      save_cfg();
      quit();
    }
    if(event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)
    {
      save_cfg();
      quit();
    }
  }
  clear_screen(0);
  print_string("Open a ROM from  File -> Open ROM", 0xFFFF, 0x0000, 8, 64);
  print_string("or drag a .gba file onto this window", 0xFFFF, 0x0000, 8, 80);
  flip_screen();
  SDL_Delay(16);
}

void pc_gui_init(void)
{
  INITCOMMONCONTROLSEX icc;
  icc.dwSize = sizeof icc;
  icc.dwICC = ICC_STANDARD_CLASSES | ICC_WIN95_CLASSES;
  InitCommonControlsEx(&icc);

  load_cfg();
  set_pc_video_scale(video_scale);
  pc_gui_attach_menu();
}

#endif
